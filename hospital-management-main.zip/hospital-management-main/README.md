# hospital-management
hospital management source code (python)
